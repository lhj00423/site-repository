<?php 
    include_once "./include/header.php";
?>


<div id = "startaw1">
    <img src="./img/compare_airpods_max__b14s2x6q07rm_large.png" alt="">
</div>
<?php 
    include_once "./include/footer.php";
?>